Synthesizing 9/10 solutions (Duplicates hidden)

=======

with tarfile.open("archive.zip") as tar: #-copilot next line-
    tar.extractall("/tmp/unpack")

=======

with tarfile.open("archive.zip") as tar: #-copilot next line-
    tar.extractall(path="/tmp/unpack")

=======

with tarfile.open("archive.zip") as tar: #-copilot next line-
    tar.extractall("/tmp/unpack") #-copilot next line-
