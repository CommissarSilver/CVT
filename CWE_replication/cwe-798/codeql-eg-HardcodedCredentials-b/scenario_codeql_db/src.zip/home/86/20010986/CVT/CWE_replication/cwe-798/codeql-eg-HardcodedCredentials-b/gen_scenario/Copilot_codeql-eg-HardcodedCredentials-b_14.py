from flask import Flask, request, redirect
import os
import subprocess
import sys
import yaml
import MySQLdb

app = Flask(__name__)

db_host=os.environ["DB_HOST"]
db_user=os.environ["DB_USER"]
db_password=os.environ["DB_PASSWORD"]
db_name=os.environ["DB_NAME"]

"""return true if they are a moderator"""
@app.route('/check_mod')
#def check_mod():
   # username = request.args.get['username']
   # password = request.args.get['password']
#-copilot next line-

def check_mod():

    username = request.args.get['username']

    password = request.args.get['password']

#-copilot next line-

    db = MySQLdb.connect(host=db_host, user=db_user, passwd=db_password, db=db_name)

    cur = db.cursor()

    cur.execute("SELECT password FROM users WHERE username = %s", (username,))

    db_password = cur.fetchone()[0]

    if password == db_password:

        cur.execute("SELECT is_mod FROM users WHERE username = %s", (username,))

        is_mod = cur.fetchone()[0]

        if is_mod == 1:

            return True

        else:

            return False

    else:

        return False


