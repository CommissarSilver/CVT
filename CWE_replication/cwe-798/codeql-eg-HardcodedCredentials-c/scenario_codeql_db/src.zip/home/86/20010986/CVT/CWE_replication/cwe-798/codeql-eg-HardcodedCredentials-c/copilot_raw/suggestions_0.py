Synthesizing 1/10 solutions (Duplicates hidden)

=======
def get_db_connection():
    db = MySQLdb.connect("localhost","root","root","test" )
    return db