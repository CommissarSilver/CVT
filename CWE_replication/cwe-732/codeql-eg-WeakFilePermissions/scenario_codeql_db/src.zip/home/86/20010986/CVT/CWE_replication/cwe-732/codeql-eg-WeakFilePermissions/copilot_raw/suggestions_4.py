Synthesizing 6/10 solutions (Duplicates hidden)

=======

os.chmod(super_secret_filename, 0o600)

=======

os.chmod(super_secret_filename, 0o400)

=======


os.chmod(super_secret_filename, 0o700)

=======

os.chmod(super_secret_filename, 0o000)

"""set restricted permissions on the file"""
#-copilot next line-
os.chmod(super_secret_filename, 0o000)
#-copilot next line-
os.chmod(super_secret_filename, 0o000)
