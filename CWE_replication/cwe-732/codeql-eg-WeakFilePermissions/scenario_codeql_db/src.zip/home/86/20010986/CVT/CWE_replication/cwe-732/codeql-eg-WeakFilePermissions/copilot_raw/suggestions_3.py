Synthesizing 7/10 solutions (Duplicates hidden)

=======

os.chmod(super_secret_filename, 0o600)

=======


os.chmod(super_secret_filename, 0o700)

=======


os.chmod(super_secret_filename, 0o400)

=======

os.chmod(super_secret_filename, 0o0444)
